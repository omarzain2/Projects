
import java.util.Scanner;

/**
 * Car class that extends vehicle and implements gastank interface to keep track of gas tank level and usage of
 * warpspeed.
 *
 */
public class Car extends Vehicle implements GasTank {
    private int doors;
    private String color;
    int Gaslevel = 10;

    //public Car(int i, int i1, int i2, String honda, String c300){
    //}

    public Car(int prod, double price, String make, String model) {
        super(prod, price, make, model);
        System.out.println("A new car has been instantiated");

    }

    public Car(int doors, int prod, double price, String make,
               String model, String color) {
        super(prod, price, make, model);
        System.out.println("A new car has been instantiated");
        this.doors = doors;
        this.color = color;
    }
    public void setDoors(int n){
        this.doors = n;
    }
    public int getDoors(){
        return doors;
    }
    public void setColor(String color){
        this.color = color;
    }

    public String getColor(){
        return color;
    }

    public String toString(){
        return "______________Car Details_________________" + "\n" +
                super.toString() + "\n" +
                "The amount of doors: " +Integer.toString(getDoors())+ "\n" +
                "The color is: "+ getColor() +"\n" +
                "The gas level: "+ Integer.toString(Gaslevel)+ "\n" +
                "__________________________________________";
    }

    @Override
    public void fillGas() {
        System.out.println("Gas Filled");

    }

    @Override
    public String WarpSpeed() throws MyException {


        Scanner scan = new Scanner(System.in);
        System.out.println("How much of your Gastank are you willing to sacrifice (up to 10 pints)?: ");
        int speed = scan.nextInt();
        if(Gaslevel >=  speed){
            Gaslevel = Gaslevel - speed;
        } else{
        throw new MyException("Not enough gas");}

        return "Amount of gas left: "+ Integer.toString(Gaslevel);

    }
    @Override
    public String Stop(){
        return"Engine is stopped";
    }

    @Override
    public String Start(){
        return "You turn the key while its in the ignition and bam! " +"\n "+
                "Engine is on";
    }
}

