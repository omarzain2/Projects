import org.w3c.dom.ls.LSOutput;

/**
 * Implemented a GasTank interface that has Start,Stop,fillGas,WarpSpeed functions
 */
interface GasTank {

    void fillGas() throws MyException;
    String Start();
    String Stop();
    String WarpSpeed() throws MyException;

}
