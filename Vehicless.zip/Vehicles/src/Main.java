import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Main class keeps track of lists and loops through list to present each new Vehicle object created
 * the addition method to each object makes sure each new object is added onto the beginning of the list inorder to give
 * each list uniqueness.
 * Iterator method used to iterate through the main Vehicles Arraylist
 */

public class Main {

	public static void main(String[] args) throws MyException {

		ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();
		ArrayList<Truck> trucks = new ArrayList<>();
		ArrayList<Car> cars = new ArrayList<>();
		ArrayList<Plane> planes = new ArrayList<>();
/**
 * (Another way of adding vehicles)
 *Vehicle[] vehicles = new Vehicle[6];
 *vehicles[0] = new Car(4, 2018, 40500, "Honda", "Odessy", "Red");
*/

		Car v1 = new Car(4, 2018, 40500, "Honda", "Odessy", "Red");
		System.out.println(v1.Start());
		System.out.println(v1.WarpSpeed());
		System.out.println(v1.WarpSpeed());
		v1.fillGas();
		v1.DisplayWindowSticker();
		Car vvv2 = new Car(2020, 35000, "BMW", "m4");
		System.out.println(vvv2.WarpSpeed());
		Car vvv3 = new Car(2021, 56000, "Alfa Romeo", "C4");
		cars.add(0, v1);
		cars.add(0, vvv2);
		cars.add(0, vvv3);

		Plane v2 = new Plane(2010, 67898, 4, 340, 10, 40000, "boeing", "e400");
		System.out.println(v2.Start());
		Plane vv2 = new Plane(2013, 67773837, 4, 344, 12, 4556, "boeing", "g550");
		Plane vv3 = new Plane(2012, 2, "KLM", "727");
		vv3.DisplayWindowSticker();
		planes.add(0, v2);
		planes.add(0, vv2);
		planes.add(0, vv3);

		Truck v3 = new Truck(2010, 5600, 3, "YES", "Honda", "Odessy", 4000);
		Truck v4 = new Truck(2010, 5600, 3, "YES", "Honda", "Odessy", 4000);
		v4.DisplayWindowSticker();
		Truck v5 = new Truck(2010, 5600, 3, "YES", "Honda", "Odessy", 4000);
		trucks.add(0, v3);
		trucks.add(0, v4);
		trucks.add(0, v5);


		for (int i = 1; i <= 2; i++) {
			//System.out.println(trucks.get(i));
			vehicles.add(trucks.get(i));
		}
		for (int i = 1; i <= 2; i++) {
			vehicles.add(cars.get(i));
		}
		for (int i = 1; i <= 2; i++) {
			vehicles.add(planes.get(i));
		}

		Iterator vehicless = vehicles.iterator();
		while (vehicless.hasNext()) {
			System.out.println(vehicless.next());

		}

	}
}