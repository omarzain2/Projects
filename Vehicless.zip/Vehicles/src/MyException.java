/**
 * An exception to stop user from using too much gas
 */
public class MyException extends Exception {

    public MyException() {
        super("MyException");
    }
    public MyException(String message){
        super(message);
    }
}
