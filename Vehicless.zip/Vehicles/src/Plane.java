
import java.util.ArrayList;
import java.util.Scanner;
/**
 * Plane class that extends vehicle and implements gastank interface to keep track of gas tank level and usage of
 * warpspeed.
 *
 */

public class Plane extends Vehicle implements GasTank {
    int amountOfEngines;
    int amountOfSeats;
    int amountOfStaff;
    double maximumLoad;
    int Gaslevel = 10;
    ArrayList<Plane> planeList = new ArrayList<>();

    public Plane(){

    }

    //ArrayList<Plane> planeList = new ArrayList<>();


    public Plane(int prod, double price, String make, String model) {
        super(prod, price, make, model);
        ArrayList<Plane> planeList = new ArrayList<>();
        //planeList.add(Plane);

    }
    public Plane(int prod, double price,int amountOfEngines, String make, String model){
        super(prod, price, make, model);
        planeList.add(new Plane());
        System.out.println("A new plane has been instantiated");
        this.amountOfEngines = amountOfEngines;
    }
    public Plane(int prod, double price,int amountOfEngines,int amountOfSeats,
                 int amountOfStaff, int maximumLoad, String make, String model){
        super(prod, price, make, model);
        planeList.add(new Plane());
        System.out.println("A new plane has been instantiated");
        this.amountOfEngines = amountOfEngines;
        this.amountOfSeats = amountOfSeats;
        this.amountOfStaff = amountOfStaff;
        this.maximumLoad = maximumLoad;
    }

    public int getAmountOfEngines() {
        return amountOfEngines;
    }

    public void setAmountOfEngines(int amountOfEngines) {
        this.amountOfEngines = amountOfEngines;
    }

    public int getAmountOfSeats() {
        return amountOfSeats;
    }

    public void setAmountOfSeats(int amountOfSeats) {
        this.amountOfSeats = amountOfSeats;
    }

    public int getAmountOfStaff() {
        return amountOfStaff;
    }

    public void setAmountOfStaff(int amountOfStaff) {
        this.amountOfStaff = amountOfStaff;
    }

    public double getMaximumLoad() {
        return maximumLoad;
    }

    public void setMaximumLoad(double maximumLoad) {
        this.maximumLoad = maximumLoad;
    }

    public String toString(){
        return "______________Plane Details_______________" + "\n" +
                super.toString() + "\n" +"The amount of engines: " +Integer.toString(getAmountOfEngines()) + "\n"
                +"The amount of seats: " +Integer.toString(getAmountOfSeats())+ "\n" +
                "The amount of staff: " +Integer.toString(getAmountOfStaff())+ "\n" +
                "The maximum load: " + Double.toString(getMaximumLoad())+ "\n" +
                "The gas level: "+ Integer.toString(Gaslevel)+ "\n" +
                "__________________________________________";
    }

    @Override
    public void fillGas() {
        Gaslevel = 10;

    }

    @Override
    public String WarpSpeed() throws MyException {


        Scanner scan = new Scanner(System.in);
        System.out.println("How much of your Gastank are you willing to sacrifice (up to 10 pints)?: ");
        int speed = scan.nextInt();
        if(Gaslevel >=  speed){
            Gaslevel = Gaslevel - speed;
        } else{
            throw new MyException("Not enough gas");}

        return "Amount of gas left: "+ Integer.toString(Gaslevel);

    }
    @Override
    public String Stop(){
        return"Engine is stopped";
    }

    @Override
    public String Start(){
        return "You flick a red button downward " +"\n "+
                "A blue button upwards " + "\n" +
                "A black button sideways and you joly the joy stick back and bam! "+ "\n" +
                "Engine is on";
    }
}
