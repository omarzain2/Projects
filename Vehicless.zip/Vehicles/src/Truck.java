import java.util.Scanner;
/**
 * Truck class that extends vehicle and implements gastank interface to keep track of gas tank level and usage of
 * warpspeed.
 *
 */

public class Truck extends Vehicle implements GasTank {
    int amountOfAxels;
    String isPickUp;
    double maximumLoad;
    boolean PickUp;
    int Gaslevel = 10;

    public Truck(){
    }

    public Truck(int prod, double price, String make, String model) {
        super(prod, price, make, model);
        System.out.println("A new truck has been instantiated");

    }

    public Truck(int prod, double price, int amountOfAxels,
                 String isPickUp, String make, String model,
                 double maximumLoad) {
        super(prod, price, make, model);
        System.out.println("A new truck has been instantiated");
        this.amountOfAxels = amountOfAxels;
        this.maximumLoad = maximumLoad;
        this.isPickUp = isPickUp;

    }

    public int getAmountOfAxels() {
        return amountOfAxels;
    }

    public void setAmountOfAxels(int amountOfAxels) {
        this.amountOfAxels = amountOfAxels;
    }

    public String getisPickUp() {
        return isPickUp;
    }

    public void setPickUp(String pickUp) {
        isPickUp = pickUp;
    }

    public double getMaximumLoad() {
        return maximumLoad;
    }

    public void setMaximumLoad(double maximumLoad) {
        this.maximumLoad = maximumLoad;
    }

    public String toString() {
        return "______________Truck Details_______________" + "\n" +
                super.toString() + "\n" + "The amount of axels: "+ Integer.toString(getAmountOfAxels()) + "\n" +
                "The maximum load is: "+ Double.toString(getMaximumLoad()) + "\n" +
                "Pickup abilities: " + getisPickUp() + "\n" +
                "The gas level: "+ Integer.toString(Gaslevel)+ "\n" +
                "__________________________________________";
    }

    @Override
    public void fillGas() {
        Gaslevel = 10;

    }

    @Override
    public String WarpSpeed() throws MyException {


        Scanner scan = new Scanner(System.in);
        System.out.println("How much of your Gastank are you willing to sacrifice (up to 10 pints)?: ");
        int speed = scan.nextInt();
        if(Gaslevel >=  speed){
            Gaslevel = Gaslevel - speed;
        } else{
            throw new MyException("Not enough gas");}

        return "Amount of gas left: "+ Integer.toString(Gaslevel);

    }
    @Override
    public String Stop(){
        return"Engine is stopped";
    }

    @Override
    public String Start(){
        return "You turn the key while its in the ignition" +"\n"+
                "Foot on the clutch and you slowly ease out of it and bam! " +"\n"+
                "Engine is on";
    }

}
