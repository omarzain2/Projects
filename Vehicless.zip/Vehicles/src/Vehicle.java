public class Vehicle<Vehicle> {
    private int production_year;
    private double price;
    private String make;
    private String model;
    private String engineState;

    public Vehicle(){
        //System.out.println("A vehicle has been instantiated");
    }

    public Vehicle(int prod, double price, String make, String model){
        this.production_year = prod;
        this.price = price;
        this.make = make;
        this.model = model;
        setEngineState("OFF");
        //System.out.println("A vehicle has been instantiated");

    }
    public void start() {
        if (this.engineState == "ON") {
            System.out.println("Engine is already on");
        } else {
            this.setEngineState("ON");
            System.out.println("Engine is on");
        }
    }
    public void stop(){
        if (this.engineState == "OFF"){
            System.out.println("Engine is already off");
        } else {
            this.setEngineState("OFF");
            System.out.println("Engine is off");
        }
    }
    public double getPrice(){
        return price;
    }
    public int getProduction_year(){
        return production_year;
    }
    public String getMake(){
        return make;
    }
    public String getModel(){
        return model;
    }
    public void setPrice(double n){
        this.price = n;
    }
    public void setProduction_year(int n){
        this.production_year = n;
    }
    public void setModel(String mdl){
        this.model = mdl;
    }
    public void setMake(String mke){
        this.make = mke;
    }
    public void setEngineState(String n){
        this.engineState = n;
    }

    public String getEngineState(){
        return engineState;
    }

    public void DisplayWindowSticker(){
        System.out.println(this.toString());
    }

    public String toString(){
        return "The production year is: " + (Integer.toString(production_year))+ "\n"+
                "The make is: " + (this.getMake())+"\n"+
                "The model is: " + (this.getModel())+"\n"+
                "The price is: " + (this.getPrice());

    }


}


